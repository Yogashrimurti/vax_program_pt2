import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class JsonHelper {
    public static final String RECIPIENT_JSON_FILE = "recipients.json";
    public static final String VC_JSON_FILE = "vaccinationCenters.json";

    private final Gson gson;

    public JsonHelper() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeDeserializer());
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer());
        this.gson = gsonBuilder.create();
    }

    static class LocalDateTimeDeserializer implements JsonDeserializer<LocalDateTime> {
        @Override
        public LocalDateTime deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
            return LocalDateTime.parse(jsonElement.getAsString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME.withLocale(Locale.ENGLISH));
        }
    }

    static class LocalDateTimeSerializer implements JsonSerializer<LocalDateTime> {
        private static final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        @Override
        public JsonElement serialize(LocalDateTime localDateTime, Type type, JsonSerializationContext jsonSerializationContext) {
            return new JsonPrimitive(formatter.format(localDateTime));
        }
    }

    public <T> ArrayList<T> readJsonFileToArrayList(String path, Class<T> className) throws IOException {
        Reader reader = Files.newBufferedReader(Paths.get(path));
        return gson.fromJson(reader, TypeToken.getParameterized(ArrayList.class, className).getType());
    }

    public <T> void writeJsonFile(ArrayList<T> recipients, String path) throws IOException {
        Writer writer = Files.newBufferedWriter(Paths.get(path));
        gson.toJson(recipients, writer);
        writer.close();
    }

    public void appendJsonArray(Object newArrayObject, String path) throws IOException {
        ArrayList<Object> data = readJsonFileToArrayList(path, Object.class);
        data.add(newArrayObject);
        writeJsonFile(data, path);
    }
}
