import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

/**
 * This generates a class to for recipient to view their current vaccine status and check the appointment date.
 */
public class Recipient {
    private final String phoneNumber;
    private String name;
    private int vaccinationStatus = 1;
    private ArrayList<Appointment> appointments;

    /**
     * A recipient is identified uniquely by a phone number
     *
     * @param phoneNumber phone number of a recipient that is registered to the system
     */
    public Recipient(String phoneNumber) throws IOException {
        this.phoneNumber = phoneNumber;
        getRemainingInfo();
    }

    /**
     * A new recipient account is registered by a phone number and a full name
     *
     * @param name        name of a recipient
     * @param phoneNumber phone number of a recipient that is registered to the system
     */
    public Recipient(String name, String phoneNumber) throws IOException {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    /**
     * get the name of a recipient
     *
     * @return name of a recipient
     */
    public String getName() {
        return this.name;
    }

    /**
     * get the phone number of a recipient
     *
     * @return phone number of a recipient
     */
    public String getPhoneNumber() {
        return this.phoneNumber;
    }

    /**
     * get the vaccination status of a recipient
     *
     * @return vaccination status of a recipient
     */
    public int getVaccinationStatus() {
        return this.vaccinationStatus;
    }

    /**
     * get the appointments of a recipient
     *
     * @return appointments of a recipient
     */
    public ArrayList<Appointment> getAppointments() {
        return this.appointments;
    }

    private boolean checkRecipientExist() throws IOException {
        ArrayList<Recipient> recipients = new JsonHelper().readJsonFileToArrayList(JsonHelper.RECIPIENT_JSON_FILE, Recipient.class);
        return recipients.stream().filter(r -> r.equals(this)).findAny().orElse(null) != null;
    }

    private void getRemainingInfo() throws IOException {
        ArrayList<Recipient> recipients = new JsonHelper().readJsonFileToArrayList(JsonHelper.RECIPIENT_JSON_FILE, Recipient.class);
        Recipient recipient = recipients.stream().filter(r -> r.equals(this)).findAny().orElse(null);
        this.name = recipient.getName();
        this.vaccinationStatus = recipient.getVaccinationStatus();
        this.appointments = recipient.getAppointments();
    }

    /**
     * register a new recipient
     *
     * @return true if register successfully or vice versa
     */
    public boolean register() throws IOException {
        if (!checkRecipientExist()) {
            new JsonHelper().appendJsonArray(this, JsonHelper.RECIPIENT_JSON_FILE);
            return true;
        }
        return false;
    }

    /**
     * log in to an existing recipient account
     *
     * @return true if the account is found
     */
    public boolean signIn() throws IOException {
        return checkRecipientExist();
    }

    /**
     * add new appointment for recipients
     *
     * @param appointment an appointment object which includes appointment details
     */
    public void addNewAppointment(Appointment appointment) {
        if (this.appointments == null) {
            this.appointments = new ArrayList<>();
        }
        this.appointments.add(appointment);
    }


    /**
     * update existing appointment for recipients
     *
     * @param dose        indicate the index of the appoinment object to be replaced
     * @param appointment a new appointment object
     */
    public void updateAppointment(int dose, Appointment appointment) {
        this.appointments.set(dose, appointment);
    }

    /**
     * increase recipient's vaccination status by 1
     */
    public void increaseVaccinationStatus() {
        this.vaccinationStatus++;
    }

    /**
     * every recipient is registered by a phone number, if the phone numbers are same, the two objects are equal
     *
     * @param o different object
     * @return whether the object are same
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Recipient recipient = (Recipient) o;
        return Objects.equals(this.phoneNumber, recipient.phoneNumber);
    }
}
