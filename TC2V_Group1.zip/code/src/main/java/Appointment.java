import java.time.LocalDateTime;

public class Appointment {
    private final String vaccinationCenter;
    private final LocalDateTime appointmentDT;

    public Appointment(String vaccinationCenter, LocalDateTime appointmentDT) {
        this.vaccinationCenter = vaccinationCenter;
        this.appointmentDT = appointmentDT;
    }

    public String getVaccinationCenter() {
        return vaccinationCenter;
    }

    public LocalDateTime getAppointmentDT() {
        return appointmentDT;
    }
}

